class PurchaseState {
  final bool isPremium;
  final String? activePlanId;
  final String? orderId;
  final String? purchaseToken;
  final DateTime? purchaseDate;
  final DateTime? expiryDate;
  final bool isAutoRenewing;

  const PurchaseState({
    this.isPremium = false,
    this.activePlanId,
    this.orderId,
    this.purchaseToken,
    this.purchaseDate,
    this.expiryDate,
    this.isAutoRenewing = false,
  });

  bool get isExpired {
    if (!isPremium) return true;
    if (expiryDate == null) return false;
    return DateTime.now().isAfter(expiryDate!);
  }

  int get remainingDays {
    if (expiryDate == null) return 0;
    final diff = expiryDate!.difference(DateTime.now()).inDays;
    return diff < 0 ? 0 : diff;
  }

  Map<String, dynamic> toMap() {
    return {
      'isPremium': isPremium,
      'activePlanId': activePlanId,
      'orderId': orderId,
      'purchaseToken': purchaseToken,
      'purchaseDate': purchaseDate?.toIso8601String(),
      'expiryDate': expiryDate?.toIso8601String(),
      'isAutoRenewing': isAutoRenewing,
    };
  }

  factory PurchaseState.fromMap(Map<String, dynamic> map) {
    return PurchaseState(
      isPremium: map['isPremium'] as bool? ?? false,
      activePlanId: map['activePlanId'] as String?,
      orderId: map['orderId'] as String?,
      purchaseToken: map['purchaseToken'] as String?,
      purchaseDate: map['purchaseDate'] != null
          ? DateTime.tryParse(map['purchaseDate'] as String)
          : null,
      expiryDate: map['expiryDate'] != null
          ? DateTime.tryParse(map['expiryDate'] as String)
          : null,
      isAutoRenewing: map['isAutoRenewing'] as bool? ?? false,
    );
  }
}
