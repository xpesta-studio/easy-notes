import 'package:in_app_purchase/in_app_purchase.dart';

class PremiumPlan {
  final String id;
  final int days;
  final String label;
  final String fallbackPrice;
  final String description;
  final bool isPopular;
  final bool isBestValue;
  ProductDetails? productDetails;

  PremiumPlan({
    required this.id,
    required this.days,
    required this.label,
    required this.fallbackPrice,
    required this.description,
    this.isPopular = false,
    this.isBestValue = false,
    this.productDetails,
  });

  /// Formatted display price: dynamically returns Google Play Billing price if loaded, or fallback price
  String get displayPrice {
    if (productDetails != null && productDetails!.price.isNotEmpty) {
      return productDetails!.price;
    }
    return fallbackPrice;
  }

  /// Estimated price per day
  String get pricePerDay {
    try {
      final numericPart = fallbackPrice.replaceAll(RegExp(r'[^0-9.]'), '');
      final priceValue = double.parse(numericPart);
      final perDay = priceValue / days;
      return '$${perDay.toStringAsFixed(3)}/day';
    } catch (_) {
      return '';
    }
  }

  /// All 10 configured Google Play Product IDs matching user specifications
  static List<PremiumPlan> get defaultPlans => [
    PremiumPlan(
      id: 'premium_3_days',
      days: 3,
      label: '3 Days Trial',
      fallbackPrice: '$0.55',
      description: 'Quick 3-day access to all premium features.',
    ),
    PremiumPlan(
      id: 'premium_7_days',
      days: 7,
      label: '7 Days Access',
      fallbackPrice: '$1.09',
      description: '1-week uninterrupted note-taking pass.',
    ),
    PremiumPlan(
      id: 'premium_15_days',
      days: 15,
      label: '15 Days Pass',
      fallbackPrice: '$2.09',
      description: 'Bi-weekly pass with premium color themes.',
    ),
    PremiumPlan(
      id: 'premium_30_days',
      days: 30,
      label: '30 Days Monthly',
      fallbackPrice: '$3.09',
      description: 'Standard monthly subscription pass.',
    ),
    PremiumPlan(
      id: 'premium_45_days',
      days: 45,
      label: '45 Days Flex',
      fallbackPrice: '$4.09',
      description: 'Extended monthly pass with higher savings.',
    ),
    PremiumPlan(
      id: 'premium_60_days',
      days: 60,
      label: '60 Days Bi-Monthly',
      fallbackPrice: '$5.09',
      description: '2 full months of unrestricted note-taking.',
    ),
    PremiumPlan(
      id: 'premium_120_days',
      days: 120,
      label: '120 Days Season',
      fallbackPrice: '$10.09',
      description: '4-month seasonal edition for active creators.',
    ),
    PremiumPlan(
      id: 'premium_365_days',
      days: 365,
      label: '365 Days (1 Year)',
      fallbackPrice: '$24.09',
      isPopular: true,
      isBestValue: true,
      description: 'Best Value! Full year of premium access.',
    ),
    PremiumPlan(
      id: 'premium_730_days',
      days: 730,
      label: '730 Days (2 Years)',
      fallbackPrice: '$52.09',
      description: '2-year edition with locked-in discount pricing.',
    ),
    PremiumPlan(
      id: 'premium_1825_days',
      days: 1825,
      label: '1825 Days (5 Years)',
      fallbackPrice: '$99.09',
      description: 'Ultra extended 5-year edition for power users.',
    ),
  ];

  /// Product IDs set for querying Google Play Console
  static Set<String> get allProductIds =>
      defaultPlans.map((p) => p.id).toSet();
}
