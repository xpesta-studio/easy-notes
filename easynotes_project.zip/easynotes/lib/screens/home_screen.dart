import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/note.dart';
import '../services/note_service.dart';
import '../services/premium_service.dart';
import '../widgets/empty_state.dart';
import '../widgets/note_card.dart';
import '../widgets/premium_bottom_sheet.dart';
import '../widgets/search_bar_widget.dart';
import '../widgets/staggered_note_grid.dart';
import 'editor_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _openEditor({Note? note}) {
    final noteService = context.read<NoteService>();
    final targetNote = note ?? noteService.createDraft();

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EditorScreen(note: targetNote),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final noteService = context.watch<NoteService>();
    final premiumService = context.watch<PremiumService>();
    final notes = noteService.notes;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Text(
              'Easy Notes',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF381E72) : const Color(0xFFEADDFF),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                'Offline',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF6750A4),
                ),
              ),
            ),
          ],
        ),
        actions: [
          // 👑 Get Premium button in AppBar
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: ActionChip(
              avatar: const Icon(Icons.workspace_premium, size: 16, color: Color(0xFFFFB300)),
              label: Text(
                premiumService.isPremium ? '👑 PRO' : '👑 Get Premium',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
              ),
              onPressed: () => PremiumBottomSheet.show(context),
              backgroundColor: premiumService.isPremium
                  ? (isDark ? const Color(0xFF381E72) : const Color(0xFFFFF8E1))
                  : null,
            ),
          ),

          IconButton(
            icon: Icon(
              noteService.viewMode == NoteViewMode.staggeredGrid
                  ? Icons.view_list_rounded
                  : Icons.grid_view_rounded,
            ),
            tooltip: 'Toggle View',
            onPressed: () => noteService.toggleViewMode(),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'Settings',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SearchBarWidget(
              controller: _searchController,
              onChanged: (q) => noteService.setSearchQuery(q),
              onClear: () => noteService.setSearchQuery(''),
            ),
          ),
          Expanded(
            child: notes.isEmpty
                ? EmptyStateWidget(
                    isSearch: noteService.searchQuery.isNotEmpty,
                    onAddNotePressed: () => _openEditor(),
                  )
                : StaggeredNoteGrid(
                    notes: notes,
                    viewMode: noteService.viewMode,
                    onNoteTap: (n) => _openEditor(note: n),
                    onPinToggle: (n) => noteService.togglePin(n.id),
                    onLongPress: (n) {},
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(),
        icon: const Icon(Icons.add),
        label: const Text('New Note'),
      ),
    );
  }
}
