import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/note_service.dart';
import '../services/premium_service.dart';
import '../services/theme_service.dart';
import '../widgets/premium_bottom_sheet.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeService = context.watch<ThemeService>();
    final noteService = context.watch<NoteService>();
    final premiumService = context.watch<PremiumService>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Google Play Billing / Subscription Card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.amber.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.workspace_premium, color: Colors.amber, size: 24),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              premiumService.isPremium ? 'Easy Notes Premium' : 'Free Edition',
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            ),
                            Text(
                              premiumService.isPremium
                                  ? 'Active plan: ${premiumService.activePlanId}'
                                  : 'Standard offline limits',
                              style: TextStyle(
                                fontSize: 12,
                                color: isDark ? Colors.grey[400] : Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                      FilledButton(
                        onPressed: () => PremiumBottomSheet.show(context),
                        child: Text(premiumService.isPremium ? 'Plans' : '👑 Upgrade'),
                      ),
                    ],
                  ),
                  const Divider(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Google Play Billing API', style: TextStyle(fontSize: 12)),
                      Text(
                        'Connected',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.green[600],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Theme Selection
          Card(
            child: Column(
              children: [
                RadioListTile<ThemeMode>(
                  title: const Text('Light Mode'),
                  subtitle: const Text('Material 3 light surface'),
                  value: ThemeMode.light,
                  groupValue: themeService.themeMode,
                  onChanged: (mode) => themeService.setThemeMode(mode!),
                ),
                RadioListTile<ThemeMode>(
                  title: const Text('Dark Mode'),
                  subtitle: const Text('OLED night palette'),
                  value: ThemeMode.dark,
                  groupValue: themeService.themeMode,
                  onChanged: (mode) => themeService.setThemeMode(mode!),
                ),
                RadioListTile<ThemeMode>(
                  title: const Text('System Default'),
                  subtitle: const Text('Match device appearance'),
                  value: ThemeMode.system,
                  groupValue: themeService.themeMode,
                  onChanged: (mode) => themeService.setThemeMode(mode!),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Local Database Info
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Stored Notes'),
                      Text('${noteService.totalNotesCount} notes', style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Database Engine'),
                      Text('Hive NoSQL (Offline)', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
