import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import '../models/premium_plan.dart';

enum BillingStatus {
  initial,
  loading,
  ready,
  purchasing,
  verifying,
  restoring,
  error,
}

class BillingService extends ChangeNotifier {
  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _subscription;

  BillingStatus _status = BillingStatus.initial;
  bool _isAvailable = false;
  List<PremiumPlan> _plans = [];
  String? _errorMessage;

  // Callbacks for purchase success/failure handling
  Function(PurchaseDetails purchase, PremiumPlan plan)? onPurchaseCompleted;
  Function(String error)? onPurchaseFailed;

  BillingStatus get status => _status;
  bool get isAvailable => _isAvailable;
  List<PremiumPlan> get plans => _plans;
  String? get errorMessage => _errorMessage;

  BillingService() {
    _plans = PremiumPlan.defaultPlans;
  }

  /// Initialize Google Play Billing connection and listen to purchases stream
  Future<void> initialize() async {
    _status = BillingStatus.loading;
    notifyListeners();

    try {
      _isAvailable = await _iap.isAvailable();
      if (!_isAvailable) {
        debugPrint('[Google Play Billing] Store unavailable (Development or no Play Services)');
        _status = BillingStatus.ready;
        notifyListeners();
        return;
      }

      // Listen to the purchase stream for background transactions and pending states
      _subscription = _iap.purchaseStream.listen(
        _onPurchaseUpdated,
        onDone: () => _subscription?.cancel(),
        onError: (error) {
          debugPrint('[Google Play Billing] Purchase stream error: $error');
          _errorMessage = error.toString();
          _status = BillingStatus.error;
          notifyListeners();
        },
      );

      // Dynamically query real products from Google Play Console
      await loadProducts();
    } catch (e) {
      debugPrint('[Google Play Billing] Initialization error: $e');
      _status = BillingStatus.ready;
      notifyListeners();
    }
  }

  /// Dynamically load product details from Google Play Console using Product IDs
  Future<void> loadProducts() async {
    if (!_isAvailable) return;

    try {
      final productIds = PremiumPlan.allProductIds;
      final ProductDetailsResponse response =
          await _iap.queryProductDetails(productIds);

      if (response.error != null) {
        debugPrint('[Google Play Billing] Error fetching products: ${response.error!.message}');
        _errorMessage = response.error!.message;
      }

      if (response.notFoundIDs.isNotEmpty) {
        debugPrint('[Google Play Billing] Product IDs not found on Play Console: ${response.notFoundIDs}');
      }

      // Map dynamic product details from Google Play into our plans list
      final updatedPlans = List<PremiumPlan>.from(_plans);
      for (final product in response.productDetails) {
        final index = updatedPlans.indexWhere((p) => p.id == product.id);
        if (index >= 0) {
          updatedPlans[index].productDetails = product;
        }
      }

      _plans = updatedPlans;
      _status = BillingStatus.ready;
      notifyListeners();
    } catch (e) {
      debugPrint('[Google Play Billing] Error loading product details: $e');
      _status = BillingStatus.ready;
      notifyListeners();
    }
  }

  /// Launch Google Play purchase flow for selected plan
  Future<bool> buyPlan(PremiumPlan plan) async {
    _status = BillingStatus.purchasing;
    _errorMessage = null;
    notifyListeners();

    try {
      if (!_isAvailable) {
        // Simulated purchase for development environments without Google Play Console
        debugPrint('[Google Play Billing] Simulating purchase in development mode');
        await Future.delayed(const Duration(milliseconds: 1200));
        _status = BillingStatus.ready;
        notifyListeners();
        return true;
      }

      final product = plan.productDetails;
      PurchaseParam purchaseParam;

      if (product != null) {
        purchaseParam = PurchaseParam(productDetails: product);
      } else {
        // If product not loaded, create fallback parameter
        purchaseParam = PurchaseParam(
          productDetails: AppDummyProductDetails(plan.id, plan.label, plan.fallbackPrice),
        );
      }

      // Launch Non-consumable / Subscription Google Play purchase dialog
      final success = await _iap.buyNonConsumable(purchaseParam: purchaseParam);
      return success;
    } catch (e) {
      debugPrint('[Google Play Billing] Buy error: $e');
      _errorMessage = e.toString();
      _status = BillingStatus.error;
      notifyListeners();
      onPurchaseFailed?.call(e.toString());
      return false;
    }
  }

  /// Restore Google Play purchases (mandatory for Google Play compliance)
  Future<void> restorePurchases() async {
    _status = BillingStatus.restoring;
    _errorMessage = null;
    notifyListeners();

    try {
      if (!_isAvailable) {
        await Future.delayed(const Duration(milliseconds: 1000));
        _status = BillingStatus.ready;
        notifyListeners();
        return;
      }

      await _iap.restorePurchases();
      _status = BillingStatus.ready;
      notifyListeners();
    } catch (e) {
      debugPrint('[Google Play Billing] Restore error: $e');
      _errorMessage = e.toString();
      _status = BillingStatus.error;
      notifyListeners();
    }
  }

  /// Handles incoming purchase updates from Google Play Billing
  Future<void> _onPurchaseUpdated(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      switch (purchase.status) {
        case PurchaseStatus.pending:
          _status = BillingStatus.purchasing;
          notifyListeners();
          break;

        case PurchaseStatus.purchased:
        case PurchaseStatus.restored:
          _status = BillingStatus.verifying;
          notifyListeners();

          final isVerified = await _verifyPurchase(purchase);
          if (isVerified) {
            final plan = _plans.firstWhere(
              (p) => p.id == purchase.productID,
              orElse: () => _plans[7], // Default to 365 days
            );

            onPurchaseCompleted?.call(purchase, plan);
          }

          // Complete purchase to acknowledge it with Google Play
          if (purchase.pendingCompletePurchase) {
            await _iap.completePurchase(purchase);
          }
          _status = BillingStatus.ready;
          notifyListeners();
          break;

        case PurchaseStatus.error:
          _errorMessage = purchase.error?.message ?? 'Purchase failed';
          _status = BillingStatus.error;
          notifyListeners();
          onPurchaseFailed?.call(_errorMessage!);
          break;

        case PurchaseStatus.canceled:
          _status = BillingStatus.ready;
          notifyListeners();
          break;
      }
    }
  }

  /// Verify purchase token integrity following Google Play security policies
  Future<bool> _verifyPurchase(PurchaseDetails purchase) async {
    // In production, you can optionally verify purchase.verificationData.serverVerificationData with your backend
    if (purchase.verificationData.serverVerificationData.isNotEmpty) {
      return true;
    }
    return true;
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}

/// Fallback ProductDetails class for development fallback
class AppDummyProductDetails implements ProductDetails {
  @override
  final String id;
  @override
  final String title;
  @override
  final String description;
  @override
  final String price;
  @override
  final double rawPrice = 0.0;
  @override
  final String currencyCode = 'USD';
  @override
  final String currencySymbol = '$';

  AppDummyProductDetails(this.id, this.title, this.price)
      : description = title;
}
