import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import '../database/hive_service.dart';
import '../models/premium_plan.dart';
import '../models/purchase_state.dart';
import 'billing_service.dart';

class PremiumService extends ChangeNotifier {
  final HiveService hiveService;
  final BillingService billingService;

  static const String _storageKey = 'easynotes_premium_purchase_state';

  PurchaseState _purchaseState = const PurchaseState();

  PurchaseState get purchaseState => _purchaseState;
  bool get isPremium => _purchaseState.isPremium && !_purchaseState.isExpired;
  String? get activePlanId => _purchaseState.activePlanId;
  int get remainingDays => _purchaseState.remainingDays;

  PremiumService({
    required this.hiveService,
    required this.billingService,
  });

  /// Initialize and load saved premium subscription from Hive
  Future<void> init() async {
    _loadSavedState();

    // Hook up callbacks from billing service
    billingService.onPurchaseCompleted = _handlePurchaseCompleted;
    billingService.onPurchaseFailed = (err) {
      debugPrint('[PremiumService] Billing error: $err');
    };

    // Auto-check and restore purchases on app start
    await checkAutoRestore();
  }

  void _loadSavedState() {
    try {
      final box = hiveService.settingsBox;
      final data = box.get(_storageKey);
      if (data != null && data is Map) {
        _purchaseState = PurchaseState.fromMap(Map<String, dynamic>.from(data));
        notifyListeners();
      }
    } catch (e) {
      debugPrint('[PremiumService] Error loading saved premium state: $e');
    }
  }

  Future<void> _saveState(PurchaseState state) async {
    _purchaseState = state;
    notifyListeners();

    try {
      final box = hiveService.settingsBox;
      await box.put(_storageKey, state.toMap());
    } catch (e) {
      debugPrint('[PremiumService] Error saving premium state: $e');
    }
  }

  void _handlePurchaseCompleted(PurchaseDetails purchase, PremiumPlan plan) {
    final now = DateTime.now();
    final expiry = now.add(Duration(days: plan.days));

    final newState = PurchaseState(
      isPremium: true,
      activePlanId: plan.id,
      orderId: purchase.purchaseID ?? 'GPA.${now.millisecondsSinceEpoch}',
      purchaseToken: purchase.verificationData.serverVerificationData,
      purchaseDate: now,
      expiryDate: expiry,
      isAutoRenewing: true,
    );

    _saveState(newState);
  }

  /// Activate simulated premium (useful in testing)
  Future<void> activateSimulatedPlan(PremiumPlan plan) async {
    final now = DateTime.now();
    final expiry = now.add(Duration(days: plan.days));

    final newState = PurchaseState(
      isPremium: true,
      activePlanId: plan.id,
      orderId: 'GPA.SIM-${now.millisecondsSinceEpoch}',
      purchaseToken: 'sim_tok_${plan.id}',
      purchaseDate: now,
      expiryDate: expiry,
      isAutoRenewing: true,
    );

    await _saveState(newState);
  }

  /// Restore purchases from Google Play
  Future<bool> restorePurchases() async {
    await billingService.restorePurchases();
    return isPremium;
  }

  /// Check auto-restoration after reinstall
  Future<void> checkAutoRestore() async {
    if (billingService.isAvailable) {
      await billingService.restorePurchases();
    }
  }
}
