import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/premium_plan.dart';
import '../services/billing_service.dart';
import '../services/premium_service.dart';

class PremiumBottomSheet extends StatefulWidget {
  const PremiumBottomSheet({super.key});

  static Future<void> show(BuildContext context) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const PremiumBottomSheet(),
    );
  }

  @override
  State<PremiumBottomSheet> createState() => _PremiumBottomSheetState();
}

class _PremiumBottomSheetState extends State<PremiumBottomSheet> {
  String _selectedPlanId = 'premium_365_days';
  bool _isProcessing = false;
  String? _statusMessage;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final billing = context.watch<BillingService>();
    final premium = context.watch<PremiumService>();

    final plans = billing.plans.isNotEmpty
        ? billing.plans
        : PremiumPlan.defaultPlans;

    final selectedPlan = plans.firstWhere(
      (p) => p.id == _selectedPlanId,
      orElse: () => plans.first,
    );

    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1D1B20) : Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 20,
            offset: Offset(0, -4),
          )
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Drag handle
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: isDark ? Colors.white24 : Colors.black12,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),

              // Crown Header
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFFB300), Color(0xFFFF8F00)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(Icons.workspace_premium, color: Colors.white, size: 36),
              ),
              const SizedBox(height: 12),

              Text(
                premium.isPremium ? 'Easy Notes Premium Active' : 'Unlock Easy Notes Premium',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 6),
              Text(
                premium.isPremium
                    ? 'Active plan: ${premium.activePlanId}. Remaining: ${premium.remainingDays} days.'
                    : 'Choose your pass. Billed via official Google Play Billing API.',
                style: TextStyle(
                  fontSize: 13,
                  color: isDark ? Colors.grey[400] : Colors.grey[600],
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),

              // Plans list (scrollable)
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 260),
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: plans.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final plan = plans[index];
                    final isSelected = plan.id == _selectedPlanId;

                    return InkWell(
                      onTap: () => setState(() => _selectedPlanId = plan.id),
                      borderRadius: BorderRadius.circular(16),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? (isDark ? const Color(0xFF381E72).withOpacity(0.5) : const Color(0xFFEADDFF).withOpacity(0.5))
                              : (isDark ? const Color(0xFF2B2930) : const Color(0xFFF7F2FA)),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isSelected
                                ? theme.colorScheme.primary
                                : (isDark ? Colors.white12 : Colors.black12),
                            width: isSelected ? 2 : 1,
                          ),
                        ),
                        child: Row(
                          children: [
                            Radio<String>(
                              value: plan.id,
                              groupValue: _selectedPlanId,
                              onChanged: (val) {
                                if (val != null) setState(() => _selectedPlanId = val);
                              },
                              activeColor: theme.colorScheme.primary,
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        plan.label,
                                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                                      ),
                                      if (plan.isBestValue) ...[
                                        const SizedBox(width: 8),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: Colors.amber[800],
                                            borderRadius: BorderRadius.circular(6),
                                          ),
                                          child: const Text(
                                            'BEST VALUE',
                                            style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold),
                                          ),
                                        )
                                      ]
                                    ],
                                  ),
                                  Text(
                                    'ID: ${plan.id} • ${plan.pricePerDay}',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: isDark ? Colors.grey[400] : Colors.grey[600],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              plan.displayPrice,
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),

              // Action button
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _isProcessing
                      ? null
                      : () async {
                          setState(() {
                            _isProcessing = true;
                            _statusMessage = null;
                          });

                          final success = await billing.buyPlan(selectedPlan);
                          if (success && !billing.isAvailable) {
                            await premium.activateSimulatedPlan(selectedPlan);
                          }

                          if (mounted) {
                            setState(() => _isProcessing = false);
                            if (success) {
                              Navigator.pop(context);
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('🎉 Premium Activated Successfully!'),
                                  backgroundColor: Colors.green,
                                ),
                              );
                            }
                          }
                        },
                  icon: _isProcessing
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.lock_open_rounded),
                  label: Text(
                    _isProcessing
                        ? 'Connecting to Google Play...'
                        : 'Get ${selectedPlan.label} — ${selectedPlan.displayPrice}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // Restore purchases button
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton.icon(
                    onPressed: () async {
                      setState(() => _isProcessing = true);
                      await premium.restorePurchases();
                      if (mounted) {
                        setState(() => _isProcessing = false);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(premium.isPremium
                                ? 'Purchases restored successfully!'
                                : 'No active subscriptions found.'),
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.restore, size: 16),
                    label: const Text('Restore Purchases', style: TextStyle(fontSize: 12)),
                  ),
                  Text(
                    'Auto-restores on reinstall',
                    style: TextStyle(
                      fontSize: 11,
                      color: isDark ? Colors.grey[500] : Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
