# Google Play Billing Integration Guide

## 1. Product IDs Configured in Easy Notes
The app dynamically loads products from Google Play Console using these 10 Product IDs:

| Product ID | Duration | Example Fallback Price |
|---|---|---|
| `premium_3_days` | 3 Days | $0.55 |
| `premium_7_days` | 7 Days | $1.09 |
| `premium_15_days` | 15 Days | $2.09 |
| `premium_30_days` | 30 Days | $3.09 |
| `premium_45_days` | 45 Days | $4.09 |
| `premium_60_days` | 60 Days | $5.09 |
| `premium_120_days` | 120 Days | $10.09 |
| `premium_365_days` | 365 Days (1 Year) | $24.09 |
| `premium_730_days` | 730 Days (2 Years) | $52.09 |
| `premium_1825_days` | 1825 Days (5 Years) | $99.09 |

## 2. Setting Up in Google Play Console
1. Open **Google Play Console** > Select your app (`com.easynotes.app`).
2. Navigate to **Monetize** > **In-app products** (or **Subscriptions**).
3. Click **Create product**.
4. Set the **Product ID** matching the table above (e.g. `premium_365_days`).
5. Enter title, description, and price in your local currencies.
6. Click **Save** and **Activate**.

## 3. License Testing
1. In Google Play Console, go to **Setup** > **License Testing**.
2. Add your tester email addresses (e.g. `xxpesta@gmail.com`).
3. Set **License test response** to `RESPOND_NORMALLY`.
4. Test purchases using test payment methods without real charges.

## 4. Production Release Build
```bash
flutter build appbundle --release
```
Upload the generated `.aab` bundle located at `build/app/outputs/bundle/release/app-release.aab` to your Google Play Console track.
